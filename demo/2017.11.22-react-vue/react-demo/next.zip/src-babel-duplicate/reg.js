console.log('reg');

export default {}