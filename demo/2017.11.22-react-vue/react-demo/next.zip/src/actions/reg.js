import { createAction } from 'redux-util'

export let reg = createAction('REG')