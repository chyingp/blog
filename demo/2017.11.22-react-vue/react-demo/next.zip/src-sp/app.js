import { React } from 'react'
import { Login } from './login'
import { Reg } from './reg'

console.log('app');