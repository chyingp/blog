import { React } from 'react'

console.log('reg');

export default {}