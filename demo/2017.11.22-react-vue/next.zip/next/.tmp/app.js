webpackJsonp([2],{

/***/ 114:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = __webpack_require__(1);

var _react2 = _interopRequireDefault(_react);

var _reactRouter = __webpack_require__(12);

var _Bundle = __webpack_require__(115);

var _Bundle2 = _interopRequireDefault(_Bundle);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Reg = function Reg(props) {
  return _react2.default.createElement(
    _Bundle2.default,
    { load: function load() {
        return __webpack_require__.e/* import() */(0).then(__webpack_require__.bind(null, 121));
      } },
    function (Reg) {
      return _react2.default.createElement(Reg, props);
    }
  );
};

var Login = function Login(props) {
  return _react2.default.createElement(
    _Bundle2.default,
    { load: function load() {
        return __webpack_require__.e/* import() */(1).then(__webpack_require__.bind(null, 122));
      } },
    function (Login) {
      return _react2.default.createElement(Login, props);
    }
  );
};

var App = function (_React$Component) {
  _inherits(App, _React$Component);

  function App(props) {
    _classCallCheck(this, App);

    var _this = _possibleConstructorReturn(this, (App.__proto__ || Object.getPrototypeOf(App)).call(this, props));

    _this.state = {};
    _this.gotoLogin = _this.gotoLogin.bind(_this);
    _this.gotoReg = _this.gotoReg.bind(_this);
    _this.gotoInquiry = _this.gotoInquiry.bind(_this);
    return _this;
  }

  _createClass(App, [{
    key: 'gotoLogin',
    value: function gotoLogin() {
      this.props.history.push(this.getLoginPath());
    }
  }, {
    key: 'getLoginPath',
    value: function getLoginPath() {
      return this.createPath('login.html');
    }
  }, {
    key: 'gotoReg',
    value: function gotoReg() {
      this.props.history.push(this.getRegPath());
    }
  }, {
    key: 'getRegPath',
    value: function getRegPath() {
      return this.createPath('reg.html');
    }
  }, {
    key: 'gotoInquiry',
    value: function gotoInquiry() {
      this.props.history.push(this.createPath('inquiry.html'));
    }
  }, {
    key: 'getInquiryPath',
    value: function getInquiryPath() {
      return this.createPath('inquiry.html');
    }

    /**
     * 根据传入的subpath，生成对应的path
     * 举例：当前页面地址为 http://dev-kh.inquiry.local/oc/kh-m/ins/0055/page/app.html
     * location.path => /oc/kh-m/ins/0055/page/app.html
     * createPath('/login') => /oc/kh-m/ins/0055/page/login
     * 
     * @param {string} subpath 
     */

  }, {
    key: 'createPath',
    value: function createPath(subpath) {
      // http://dev-kh.inquiry.local/oc/kh-m/ins/0055/page/app.html
      return location.pathname.replace(/page\/.+$/, 'page/' + subpath);
    }
  }, {
    key: 'renderAsyncComponent',
    value: function renderAsyncComponent() {
      // return React.createElement(Reg);

    }
  }, {
    key: 'render',
    value: function render() {
      return _react2.default.createElement(
        'div',
        null,
        _react2.default.createElement(
          'a',
          { href: 'javascript:void(0)', onClick: this.gotoLogin },
          '\u767B\u5F55'
        ),
        _react2.default.createElement(
          'a',
          { href: 'javascript:void(0)', onClick: this.gotoReg },
          '\u6CE8\u518C'
        ),
        _react2.default.createElement(
          'a',
          { href: 'javascript:void(0)', onClick: this.gotoInquiry },
          '\u8BE2\u4EF7'
        ),
        _react2.default.createElement(_reactRouter.Route, { path: this.getLoginPath(), component: Login }),
        _react2.default.createElement(_reactRouter.Route, { path: this.getRegPath(), component: Reg })
      );
    }
  }]);

  return App;
}(_react2.default.Component);

exports.default = App;

/***/ }),

/***/ 115:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = __webpack_require__(1);

var _react2 = _interopRequireDefault(_react);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Bundle = function (_Component) {
  _inherits(Bundle, _Component);

  function Bundle() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Bundle);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Bundle.__proto__ || Object.getPrototypeOf(Bundle)).call.apply(_ref, [this].concat(args))), _this), _this.state = {
      // short for "module" but that's a keyword in js, so "mod"
      mod: null
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Bundle, [{
    key: 'componentWillMount',
    value: function componentWillMount() {
      this.load(this.props);
    }
  }, {
    key: 'componentWillReceiveProps',
    value: function componentWillReceiveProps(nextProps) {
      if (nextProps.load !== this.props.load) {
        this.load(nextProps);
      }
    }
  }, {
    key: 'load',
    value: function load(props) {
      var _this2 = this;

      this.setState({
        mod: null
      });
      props.load().then(function (mod) {
        _this2.setState({
          // handle both es imports and cjs
          mod: mod.default ? mod.default : mod
        });
      });
      // props.load((mod) => {
      //   this.setState({
      //     // handle both es imports and cjs
      //     mod: mod.default ? mod.default : mod
      //   })
      // })
    }
  }, {
    key: 'render',
    value: function render() {
      return this.state.mod ? this.props.children(this.state.mod) : null;
    }
  }]);

  return Bundle;
}(_react.Component);

exports.default = Bundle;

/***/ }),

/***/ 39:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var defaultPayloadCreator = function defaultPayloadCreator(payload) {
	return payload;
};

module.exports = function (type, payloadCreator) {

	var finialPayloadCreator = typeof payloadCreator === 'function' ? payloadCreator : defaultPayloadCreator;

	return function () {
		var payload = finialPayloadCreator.apply(null, arguments);

		if (typeof payload === 'function') {
			return payload;
		} else {
			return {
				type: type,
				payload: payload
			};
		}
	};
};

/***/ }),

/***/ 52:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var createAction = __webpack_require__(39);
var createActions = __webpack_require__(91);
var createReducers = __webpack_require__(92);
var createReducer = __webpack_require__(94);

module.exports = {
	createAction: createAction,
	createActions: createActions,
	createReducers: createReducers,
	createReducer: createReducer
};

/***/ }),

/***/ 53:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _react = __webpack_require__(1);

var _react2 = _interopRequireDefault(_react);

var _reactDom = __webpack_require__(50);

var _redux = __webpack_require__(28);

var _reduxThunk = __webpack_require__(78);

var _reduxThunk2 = _interopRequireDefault(_reduxThunk);

var _reactRedux = __webpack_require__(51);

var _reducers = __webpack_require__(90);

var _reducers2 = _interopRequireDefault(_reducers);

var _createBrowserHistory = __webpack_require__(95);

var _createBrowserHistory2 = _interopRequireDefault(_createBrowserHistory);

var _reactRouter = __webpack_require__(12);

var _reactRouterRedux = __webpack_require__(110);

var _App = __webpack_require__(114);

var _App2 = _interopRequireDefault(_App);

__webpack_require__(116);

__webpack_require__(119);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var history = (0, _createBrowserHistory2.default)();
var middleware = (0, _reactRouterRedux.routerMiddleware)(history);

history.listen(function (location, action) {
  // location is an object like window.location
  console.log(action, location.pathname, location.state);
});

var store = (0, _redux.createStore)((0, _redux.combineReducers)(_extends({}, _reducers2.default, {
  router: _reactRouterRedux.routerReducer
})), (0, _redux.applyMiddleware)(_reduxThunk2.default, middleware));

var mapStateToProps = function mapStateToProps(state) {
  return state;
};

// 样式文件


(0, _reactDom.render)(_react2.default.createElement(
  _reactRedux.Provider,
  { store: store },
  _react2.default.createElement(
    _reactRouterRedux.ConnectedRouter,
    { history: history },
    _react2.default.createElement(_App2.default, { history: history })
  )
), document.getElementById('container'));

/***/ }),

/***/ 90:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
	value: true
});

var _reduxUtil = __webpack_require__(52);

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var loginApp = (0, _reduxUtil.createReducers)({
	getInitialState: function getInitialState() {
		return {
			loginStatus: '',
			regStatus: ''
		};
	},
	LOGIN: function LOGIN(state, action) {
		state.loginStatus = 'pending';
		return state;
	}
});

var regApp = (0, _reduxUtil.createReducers)({
	getInitialState: function getInitialState() {
		return _defineProperty({
			regStatus: ''
		}, 'regStatus', '');
	},
	LOGIN: function LOGIN(state, action) {
		state.regStatus = 'pending';
		return state;
	}
});

var reducer = {
	loginApp: loginApp,
	regApp: regApp
};

exports.default = reducer;

/***/ }),

/***/ 91:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var createAction = __webpack_require__(39);

module.exports = function (options) {
	var actionMap = {};
	for (var type in options) {
		actionMap[type] = createAction(type, options[type]);
	}
	return actionMap;
};

/***/ }),

/***/ 92:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _ = __webpack_require__(93);

module.exports = function (reducerMap) {

	var initialState;

	if (reducerMap.getInitialState) {
		initialState = reducerMap.getInitialState();
	}

	return function () {
		var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : initialState;
		var action = arguments[1];


		state = _.clone(state);

		var type = action.type;
		var reducer = reducerMap[type];

		if (typeof reducer === 'function') {
			return reducer(state, action);
		} else {
			return state;
		}
	};
};

/***/ }),

/***/ 94:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = function (type, reducer, initialState) {
	return function (state, action) {
		if (action.type !== type) return state;

		return reducer(type, action);
	};
};

/***/ })

},[53]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9BcHAuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvQnVuZGxlLmpzIiwid2VicGFjazovLy8uL3NyYy9tb2R1bGVzL3JlZHV4LXV0aWwvY3JlYXRlQWN0aW9uLmpzIiwid2VicGFjazovLy8uL3NyYy9tb2R1bGVzL3JlZHV4LXV0aWwvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2xpYi9hcHAuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3JlZHVjZXJzL2luZGV4LmpzIiwid2VicGFjazovLy8uL3NyYy9tb2R1bGVzL3JlZHV4LXV0aWwvY3JlYXRlQWN0aW9ucy5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvbW9kdWxlcy9yZWR1eC11dGlsL2NyZWF0ZVJlZHVjZXJzLmpzIiwid2VicGFjazovLy8uL3NyYy9tb2R1bGVzL3JlZHV4LXV0aWwvY3JlYXRlUmVkdWNlci5qcyJdLCJuYW1lcyI6WyJSZWciLCJwcm9wcyIsIkxvZ2luIiwiQXBwIiwic3RhdGUiLCJnb3RvTG9naW4iLCJiaW5kIiwiZ290b1JlZyIsImdvdG9JbnF1aXJ5IiwiaGlzdG9yeSIsInB1c2giLCJnZXRMb2dpblBhdGgiLCJjcmVhdGVQYXRoIiwiZ2V0UmVnUGF0aCIsInN1YnBhdGgiLCJsb2NhdGlvbiIsInBhdGhuYW1lIiwicmVwbGFjZSIsIkNvbXBvbmVudCIsIkJ1bmRsZSIsIm1vZCIsImxvYWQiLCJuZXh0UHJvcHMiLCJzZXRTdGF0ZSIsInRoZW4iLCJkZWZhdWx0IiwiY2hpbGRyZW4iLCJkZWZhdWx0UGF5bG9hZENyZWF0b3IiLCJwYXlsb2FkIiwibW9kdWxlIiwiZXhwb3J0cyIsInR5cGUiLCJwYXlsb2FkQ3JlYXRvciIsImZpbmlhbFBheWxvYWRDcmVhdG9yIiwiYXBwbHkiLCJhcmd1bWVudHMiLCJjcmVhdGVBY3Rpb24iLCJyZXF1aXJlIiwiY3JlYXRlQWN0aW9ucyIsImNyZWF0ZVJlZHVjZXJzIiwiY3JlYXRlUmVkdWNlciIsIm1pZGRsZXdhcmUiLCJsaXN0ZW4iLCJhY3Rpb24iLCJjb25zb2xlIiwibG9nIiwic3RvcmUiLCJyb3V0ZXIiLCJtYXBTdGF0ZVRvUHJvcHMiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwibG9naW5BcHAiLCJnZXRJbml0aWFsU3RhdGUiLCJsb2dpblN0YXR1cyIsInJlZ1N0YXR1cyIsIkxPR0lOIiwicmVnQXBwIiwicmVkdWNlciIsIm9wdGlvbnMiLCJhY3Rpb25NYXAiLCJfIiwicmVkdWNlck1hcCIsImluaXRpYWxTdGF0ZSIsImNsb25lIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQUFBOzs7O0FBQ0E7O0FBQ0E7Ozs7Ozs7Ozs7OztBQUVBLElBQU1BLE1BQU0sU0FBTkEsR0FBTSxDQUFDQyxLQUFEO0FBQUEsU0FDVjtBQUFBO0FBQUEsTUFBUSxNQUFNO0FBQUEsZUFBTSxnRkFBTjtBQUFBLE9BQWQ7QUFDRyxjQUFDRCxHQUFEO0FBQUEsYUFBUyw4QkFBQyxHQUFELEVBQVNDLEtBQVQsQ0FBVDtBQUFBO0FBREgsR0FEVTtBQUFBLENBQVo7O0FBTUEsSUFBTUMsUUFBUSxTQUFSQSxLQUFRLENBQUNELEtBQUQ7QUFBQSxTQUNaO0FBQUE7QUFBQSxNQUFRLE1BQU07QUFBQSxlQUFNLGdGQUFOO0FBQUEsT0FBZDtBQUNHLGNBQUNDLEtBQUQ7QUFBQSxhQUFXLDhCQUFDLEtBQUQsRUFBV0QsS0FBWCxDQUFYO0FBQUE7QUFESCxHQURZO0FBQUEsQ0FBZDs7SUFNTUUsRzs7O0FBRUosZUFBWUYsS0FBWixFQUFrQjtBQUFBOztBQUFBLDBHQUNWQSxLQURVOztBQUdoQixVQUFLRyxLQUFMLEdBQWEsRUFBYjtBQUNBLFVBQUtDLFNBQUwsR0FBaUIsTUFBS0EsU0FBTCxDQUFlQyxJQUFmLE9BQWpCO0FBQ0EsVUFBS0MsT0FBTCxHQUFlLE1BQUtBLE9BQUwsQ0FBYUQsSUFBYixPQUFmO0FBQ0EsVUFBS0UsV0FBTCxHQUFtQixNQUFLQSxXQUFMLENBQWlCRixJQUFqQixPQUFuQjtBQU5nQjtBQU9qQjs7OztnQ0FFWTtBQUNYLFdBQUtMLEtBQUwsQ0FBV1EsT0FBWCxDQUFtQkMsSUFBbkIsQ0FBeUIsS0FBS0MsWUFBTCxFQUF6QjtBQUNEOzs7bUNBRWU7QUFDZCxhQUFPLEtBQUtDLFVBQUwsQ0FBZ0IsWUFBaEIsQ0FBUDtBQUNEOzs7OEJBRVM7QUFDUixXQUFLWCxLQUFMLENBQVdRLE9BQVgsQ0FBbUJDLElBQW5CLENBQXlCLEtBQUtHLFVBQUwsRUFBekI7QUFDRDs7O2lDQUVhO0FBQ1osYUFBTyxLQUFLRCxVQUFMLENBQWdCLFVBQWhCLENBQVA7QUFDRDs7O2tDQUVjO0FBQ2IsV0FBS1gsS0FBTCxDQUFXUSxPQUFYLENBQW1CQyxJQUFuQixDQUF5QixLQUFLRSxVQUFMLENBQWdCLGNBQWhCLENBQXpCO0FBQ0Q7OztxQ0FFaUI7QUFDaEIsYUFBTyxLQUFLQSxVQUFMLENBQWdCLGNBQWhCLENBQVA7QUFDRDs7QUFFRDs7Ozs7Ozs7Ozs7K0JBUVlFLE8sRUFBUztBQUNuQjtBQUNBLGFBQU9DLFNBQVNDLFFBQVQsQ0FBa0JDLE9BQWxCLENBQTBCLFdBQTFCLEVBQXVDLFVBQVVILE9BQWpELENBQVA7QUFDRDs7OzJDQUV1QjtBQUN0Qjs7QUFFRDs7OzZCQUVTO0FBQ1IsYUFDRTtBQUFBO0FBQUE7QUFDRDtBQUFBO0FBQUEsWUFBRyxNQUFLLG9CQUFSLEVBQTZCLFNBQVMsS0FBS1QsU0FBM0M7QUFBQTtBQUFBLFNBREM7QUFFQztBQUFBO0FBQUEsWUFBRyxNQUFLLG9CQUFSLEVBQTZCLFNBQVMsS0FBS0UsT0FBM0M7QUFBQTtBQUFBLFNBRkQ7QUFHSTtBQUFBO0FBQUEsWUFBRyxNQUFLLG9CQUFSLEVBQTZCLFNBQVMsS0FBS0MsV0FBM0M7QUFBQTtBQUFBLFNBSEo7QUFJRCw0REFBTyxNQUFNLEtBQUtHLFlBQUwsRUFBYixFQUFrQyxXQUFXVCxLQUE3QyxHQUpDO0FBS0ksNERBQU8sTUFBTSxLQUFLVyxVQUFMLEVBQWIsRUFBZ0MsV0FBV2IsR0FBM0M7QUFMSixPQURGO0FBV0Q7Ozs7RUFqRWUsZ0JBQU1rQixTOztrQkFvRVRmLEc7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwRmY7Ozs7Ozs7Ozs7OztJQUVNZ0IsTTs7Ozs7Ozs7Ozs7Ozs7c0xBQ0pmLEssR0FBUTtBQUNOO0FBQ0FnQixXQUFLO0FBRkMsSzs7Ozs7eUNBS2E7QUFDbkIsV0FBS0MsSUFBTCxDQUFVLEtBQUtwQixLQUFmO0FBQ0Q7Ozs4Q0FFeUJxQixTLEVBQVc7QUFDbkMsVUFBSUEsVUFBVUQsSUFBVixLQUFtQixLQUFLcEIsS0FBTCxDQUFXb0IsSUFBbEMsRUFBd0M7QUFDdEMsYUFBS0EsSUFBTCxDQUFVQyxTQUFWO0FBQ0Q7QUFDRjs7O3lCQUVJckIsSyxFQUFPO0FBQUE7O0FBQ1YsV0FBS3NCLFFBQUwsQ0FBYztBQUNaSCxhQUFLO0FBRE8sT0FBZDtBQUdBbkIsWUFDR29CLElBREgsR0FFR0csSUFGSCxDQUVRLFVBQUNKLEdBQUQsRUFBUztBQUNiLGVBQUtHLFFBQUwsQ0FBYztBQUNaO0FBQ0FILGVBQUtBLElBQUlLLE9BQUosR0FBY0wsSUFBSUssT0FBbEIsR0FBNEJMO0FBRnJCLFNBQWQ7QUFJRCxPQVBIO0FBUUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Q7Ozs2QkFFUTtBQUNQLGFBQU8sS0FBS2hCLEtBQUwsQ0FBV2dCLEdBQVgsR0FBaUIsS0FBS25CLEtBQUwsQ0FBV3lCLFFBQVgsQ0FBb0IsS0FBS3RCLEtBQUwsQ0FBV2dCLEdBQS9CLENBQWpCLEdBQXVELElBQTlEO0FBQ0Q7Ozs7OztrQkFHWUQsTTs7Ozs7Ozs7OztBQzNDZixJQUFJUSx3QkFBd0IsU0FBeEJBLHFCQUF3QixDQUFVQyxPQUFWLEVBQW1CO0FBQzlDLFFBQU9BLE9BQVA7QUFDQSxDQUZEOztBQUlBQyxPQUFPQyxPQUFQLEdBQWlCLFVBQVNDLElBQVQsRUFBZUMsY0FBZixFQUE4Qjs7QUFFOUMsS0FBSUMsdUJBQXVCLE9BQU9ELGNBQVAsS0FBMEIsVUFBMUIsR0FDeEJBLGNBRHdCLEdBRXhCTCxxQkFGSDs7QUFJQSxRQUFPLFlBQVk7QUFDbEIsTUFBSUMsVUFBVUsscUJBQXFCQyxLQUFyQixDQUEyQixJQUEzQixFQUFpQ0MsU0FBakMsQ0FBZDs7QUFFQSxNQUFJLE9BQU9QLE9BQVAsS0FBbUIsVUFBdkIsRUFBbUM7QUFDbEMsVUFBT0EsT0FBUDtBQUNBLEdBRkQsTUFFTztBQUNOLFVBQU87QUFDTkcsVUFBTUEsSUFEQTtBQUVOSCxhQUFTQTtBQUZILElBQVA7QUFJQTtBQUNELEVBWEQ7QUFZQSxDQWxCRCxDOzs7Ozs7Ozs7O0FDSkEsSUFBSVEsZUFBZSxtQkFBQUMsQ0FBUSxFQUFSLENBQW5CO0FBQ0EsSUFBSUMsZ0JBQWdCLG1CQUFBRCxDQUFRLEVBQVIsQ0FBcEI7QUFDQSxJQUFJRSxpQkFBaUIsbUJBQUFGLENBQVEsRUFBUixDQUFyQjtBQUNBLElBQUlHLGdCQUFnQixtQkFBQUgsQ0FBUSxFQUFSLENBQXBCOztBQUVBUixPQUFPQyxPQUFQLEdBQWlCO0FBQ2hCTSwyQkFEZ0I7QUFFaEJFLDZCQUZnQjtBQUdoQkMsK0JBSGdCO0FBSWhCQztBQUpnQixDQUFqQixDOzs7Ozs7Ozs7Ozs7QUNMQTs7OztBQUNBOztBQUVBOztBQUNBOzs7O0FBQ0E7O0FBQ0E7Ozs7QUFFQTs7OztBQUNBOztBQUVBOztBQXNCQTs7OztBQUdBOztBQUNBOzs7O0FBeEJBLElBQU0vQixVQUFVLHFDQUFoQjtBQUNBLElBQU1nQyxhQUFhLHdDQUFpQmhDLE9BQWpCLENBQW5COztBQUVBQSxRQUFRaUMsTUFBUixDQUFlLFVBQUMzQixRQUFELEVBQVc0QixNQUFYLEVBQXNCO0FBQ25DO0FBQ0FDLFVBQVFDLEdBQVIsQ0FBWUYsTUFBWixFQUFvQjVCLFNBQVNDLFFBQTdCLEVBQXVDRCxTQUFTWCxLQUFoRDtBQUNELENBSEQ7O0FBS0EsSUFBTTBDLFFBQVEsd0JBQ1o7QUFFRUM7QUFGRixHQURZLEVBS1osa0RBQXVCTixVQUF2QixDQUxZLENBQWQ7O0FBUUEsSUFBTU8sa0JBQWtCLFNBQWxCQSxlQUFrQixDQUFTNUMsS0FBVCxFQUFlO0FBQ3RDLFNBQU9BLEtBQVA7QUFDQSxDQUZEOztBQU1BOzs7QUFJQSxzQkFDRTtBQUFBO0FBQUEsSUFBVSxPQUFPMEMsS0FBakI7QUFFRTtBQUFBO0FBQUEsTUFBaUIsU0FBU3JDLE9BQTFCO0FBQ0QsbURBQUssU0FBU0EsT0FBZDtBQURDO0FBRkYsQ0FERixFQU9Fd0MsU0FBU0MsY0FBVCxDQUF3QixXQUF4QixDQVBGLEU7Ozs7Ozs7Ozs7Ozs7O0FDdkNBOzs7O0FBRUEsSUFBSUMsV0FBVywrQkFBZTtBQUM3QkMsa0JBQWlCLDJCQUFVO0FBQzFCLFNBQU87QUFDTkMsZ0JBQWEsRUFEUDtBQUVOQyxjQUFXO0FBRkwsR0FBUDtBQUlBLEVBTjRCO0FBTzdCQyxRQUFPLGVBQVNuRCxLQUFULEVBQWdCdUMsTUFBaEIsRUFBdUI7QUFDN0J2QyxRQUFNaUQsV0FBTixHQUFvQixTQUFwQjtBQUNBLFNBQU9qRCxLQUFQO0FBQ0E7QUFWNEIsQ0FBZixDQUFmOztBQWFBLElBQUlvRCxTQUFTLCtCQUFlO0FBQzNCSixrQkFBaUIsMkJBQVU7QUFDMUI7QUFDQ0UsY0FBVztBQURaLGtCQUVZLEVBRlo7QUFJQSxFQU4wQjtBQU8zQkMsUUFBTyxlQUFTbkQsS0FBVCxFQUFnQnVDLE1BQWhCLEVBQXVCO0FBQzdCdkMsUUFBTWtELFNBQU4sR0FBa0IsU0FBbEI7QUFDQSxTQUFPbEQsS0FBUDtBQUNBO0FBVjBCLENBQWYsQ0FBYjs7QUFhQSxJQUFNcUQsVUFBVTtBQUNmTixXQUFVQSxRQURLO0FBRWZLLFNBQVFBO0FBRk8sQ0FBaEI7O2tCQUtlQyxPOzs7Ozs7Ozs7O0FDakNmLElBQUlyQixlQUFlLG1CQUFBQyxDQUFRLEVBQVIsQ0FBbkI7O0FBRUFSLE9BQU9DLE9BQVAsR0FBaUIsVUFBUzRCLE9BQVQsRUFBaUI7QUFDakMsS0FBSUMsWUFBWSxFQUFoQjtBQUNBLE1BQUksSUFBSTVCLElBQVIsSUFBZ0IyQixPQUFoQixFQUF3QjtBQUN2QkMsWUFBVTVCLElBQVYsSUFBa0JLLGFBQWFMLElBQWIsRUFBbUIyQixRQUFRM0IsSUFBUixDQUFuQixDQUFsQjtBQUNBO0FBQ0QsUUFBTzRCLFNBQVA7QUFDQSxDQU5ELEM7Ozs7Ozs7Ozs7QUNGQSxJQUFJQyxJQUFJLG1CQUFBdkIsQ0FBUSxFQUFSLENBQVI7O0FBRUFSLE9BQU9DLE9BQVAsR0FBaUIsVUFBVStCLFVBQVYsRUFBc0I7O0FBRXRDLEtBQUlDLFlBQUo7O0FBRUEsS0FBR0QsV0FBV1QsZUFBZCxFQUE4QjtBQUM3QlUsaUJBQWVELFdBQVdULGVBQVgsRUFBZjtBQUNBOztBQUVELFFBQU8sWUFBd0M7QUFBQSxNQUE5QmhELEtBQThCLHVFQUF0QjBELFlBQXNCO0FBQUEsTUFBUm5CLE1BQVE7OztBQUU5Q3ZDLFVBQVF3RCxFQUFFRyxLQUFGLENBQVEzRCxLQUFSLENBQVI7O0FBRUEsTUFBSTJCLE9BQU9ZLE9BQU9aLElBQWxCO0FBQ0EsTUFBSTBCLFVBQVVJLFdBQVc5QixJQUFYLENBQWQ7O0FBRUEsTUFBRyxPQUFPMEIsT0FBUCxLQUFtQixVQUF0QixFQUFpQztBQUNoQyxVQUFPQSxRQUFRckQsS0FBUixFQUFldUMsTUFBZixDQUFQO0FBQ0EsR0FGRCxNQUVLO0FBQ0osVUFBT3ZDLEtBQVA7QUFDQTtBQUNELEVBWkQ7QUFhQSxDQXJCRCxDOzs7Ozs7Ozs7O0FDRkF5QixPQUFPQyxPQUFQLEdBQWlCLFVBQVNDLElBQVQsRUFBZTBCLE9BQWYsRUFBd0JLLFlBQXhCLEVBQXFDO0FBQ3JELFFBQU8sVUFBVTFELEtBQVYsRUFBaUJ1QyxNQUFqQixFQUF5QjtBQUMvQixNQUFHQSxPQUFPWixJQUFQLEtBQWdCQSxJQUFuQixFQUF5QixPQUFPM0IsS0FBUDs7QUFFekIsU0FBT3FELFFBQVExQixJQUFSLEVBQWNZLE1BQWQsQ0FBUDtBQUNBLEVBSkQ7QUFLQSxDQU5ELEMiLCJmaWxlIjoiYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgUm91dGUgfSBmcm9tICdyZWFjdC1yb3V0ZXInXG5pbXBvcnQgQnVuZGxlIGZyb20gJy4vQnVuZGxlJ1xuXG5jb25zdCBSZWcgPSAocHJvcHMpID0+IChcbiAgPEJ1bmRsZSBsb2FkPXsoKSA9PiBpbXBvcnQoLyogd2VicGFja0NodW5rTmFtZTogXCJyZWdcIiAqLyAnLi4vY29udGFpbmVycy9SZWcnKX0+XG4gICAgeyhSZWcpID0+IDxSZWcgey4uLnByb3BzfS8+fVxuICA8L0J1bmRsZT5cbilcblxuY29uc3QgTG9naW4gPSAocHJvcHMpID0+IChcbiAgPEJ1bmRsZSBsb2FkPXsoKSA9PiBpbXBvcnQoLyogd2VicGFja0NodW5rTmFtZTogXCJsb2dpblwiICovICcuLi9jb250YWluZXJzL0xvZ2luJyl9PlxuICAgIHsoTG9naW4pID0+IDxMb2dpbiB7Li4ucHJvcHN9Lz59XG4gIDwvQnVuZGxlPlxuKVxuXG5jbGFzcyBBcHAgZXh0ZW5kcyBSZWFjdC5Db21wb25lbnQge1xuICBcbiAgY29uc3RydWN0b3IocHJvcHMpe1xuICAgIHN1cGVyKHByb3BzKVxuXG4gICAgdGhpcy5zdGF0ZSA9IHt9XG4gICAgdGhpcy5nb3RvTG9naW4gPSB0aGlzLmdvdG9Mb2dpbi5iaW5kKHRoaXMpXG4gICAgdGhpcy5nb3RvUmVnID0gdGhpcy5nb3RvUmVnLmJpbmQodGhpcylcbiAgICB0aGlzLmdvdG9JbnF1aXJ5ID0gdGhpcy5nb3RvSW5xdWlyeS5iaW5kKHRoaXMpICAgIFxuICB9XG5cbiAgZ290b0xvZ2luICgpIHtcbiAgICB0aGlzLnByb3BzLmhpc3RvcnkucHVzaCggdGhpcy5nZXRMb2dpblBhdGgoKSApXG4gIH1cblxuICBnZXRMb2dpblBhdGggKCkge1xuICAgIHJldHVybiB0aGlzLmNyZWF0ZVBhdGgoJ2xvZ2luLmh0bWwnKVxuICB9XG5cbiAgZ290b1JlZygpIHtcbiAgICB0aGlzLnByb3BzLmhpc3RvcnkucHVzaCggdGhpcy5nZXRSZWdQYXRoKCkgKVxuICB9XG5cbiAgZ2V0UmVnUGF0aCAoKSB7XG4gICAgcmV0dXJuIHRoaXMuY3JlYXRlUGF0aCgncmVnLmh0bWwnKVxuICB9XG5cbiAgZ290b0lucXVpcnkgKCkge1xuICAgIHRoaXMucHJvcHMuaGlzdG9yeS5wdXNoKCB0aGlzLmNyZWF0ZVBhdGgoJ2lucXVpcnkuaHRtbCcpIClcbiAgfVxuXG4gIGdldElucXVpcnlQYXRoICgpIHtcbiAgICByZXR1cm4gdGhpcy5jcmVhdGVQYXRoKCdpbnF1aXJ5Lmh0bWwnKVxuICB9XG5cbiAgLyoqXG4gICAqIOagueaNruS8oOWFpeeahHN1YnBhdGjvvIznlJ/miJDlr7nlupTnmoRwYXRoXG4gICAqIOS4vuS+i++8muW9k+WJjemhtemdouWcsOWdgOS4uiBodHRwOi8vZGV2LWtoLmlucXVpcnkubG9jYWwvb2Mva2gtbS9pbnMvMDA1NS9wYWdlL2FwcC5odG1sXG4gICAqIGxvY2F0aW9uLnBhdGggPT4gL29jL2toLW0vaW5zLzAwNTUvcGFnZS9hcHAuaHRtbFxuICAgKiBjcmVhdGVQYXRoKCcvbG9naW4nKSA9PiAvb2Mva2gtbS9pbnMvMDA1NS9wYWdlL2xvZ2luXG4gICAqIFxuICAgKiBAcGFyYW0ge3N0cmluZ30gc3VicGF0aCBcbiAgICovXG4gIGNyZWF0ZVBhdGggKHN1YnBhdGgpIHtcbiAgICAvLyBodHRwOi8vZGV2LWtoLmlucXVpcnkubG9jYWwvb2Mva2gtbS9pbnMvMDA1NS9wYWdlL2FwcC5odG1sXG4gICAgcmV0dXJuIGxvY2F0aW9uLnBhdGhuYW1lLnJlcGxhY2UoL3BhZ2VcXC8uKyQvLCAncGFnZS8nICsgc3VicGF0aCk7XG4gIH1cblxuICByZW5kZXJBc3luY0NvbXBvbmVudCAoKSB7XG4gICAgLy8gcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoUmVnKTtcblxuICB9XG5cbiAgcmVuZGVyICgpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdj5cblx0XHRcdFx0XHQ8YSBocmVmPVwiamF2YXNjcmlwdDp2b2lkKDApXCIgb25DbGljaz17dGhpcy5nb3RvTG9naW59PueZu+W9lTwvYT5cblx0XHRcdCAgICA8YSBocmVmPVwiamF2YXNjcmlwdDp2b2lkKDApXCIgb25DbGljaz17dGhpcy5nb3RvUmVnfT7ms6jlhow8L2E+XG4gICAgICAgICAgPGEgaHJlZj1cImphdmFzY3JpcHQ6dm9pZCgwKVwiIG9uQ2xpY2s9e3RoaXMuZ290b0lucXVpcnl9PuivouS7tzwvYT5cblx0XHRcdFx0XHQ8Um91dGUgcGF0aD17dGhpcy5nZXRMb2dpblBhdGgoKX0gY29tcG9uZW50PXtMb2dpbn0vPlxuICAgICAgICAgIDxSb3V0ZSBwYXRoPXt0aGlzLmdldFJlZ1BhdGgoKX0gY29tcG9uZW50PXtSZWd9Lz5cbiAgICAgICAgICB7LyogPFJvdXRlIHBhdGg9e3RoaXMuZ2V0UmVnUGF0aCgpfSByZW5kZXI9e3RoaXMucmVuZGVyQXN5bmNDb21wb25lbnQuYmluZCh0aGlzLCAnLi9yZWcnKX0vPiAqL31cbiAgICAgICAgICB7LyogPFJvdXRlIHBhdGg9e3RoaXMuZ2V0SW5xdWlyeVBhdGgoKX0gcmVuZGVyPXt0aGlzLnJlbmRlckFzeW5jQ29tcG9uZW50LmJpbmQodGhpcywgJycpfSAvPiAqL31cbiAgICAgIDwvZGl2PlxuICAgIClcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBBcHBcblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi9zcmMvY29tcG9uZW50cy9BcHAuanMiLCJpbXBvcnQgUmVhY3QsIHsgQ29tcG9uZW50IH0gZnJvbSAncmVhY3QnXG5cbmNsYXNzIEJ1bmRsZSBleHRlbmRzIENvbXBvbmVudCB7XG4gIHN0YXRlID0ge1xuICAgIC8vIHNob3J0IGZvciBcIm1vZHVsZVwiIGJ1dCB0aGF0J3MgYSBrZXl3b3JkIGluIGpzLCBzbyBcIm1vZFwiXG4gICAgbW9kOiBudWxsXG4gIH1cblxuICBjb21wb25lbnRXaWxsTW91bnQoKSB7XG4gICAgdGhpcy5sb2FkKHRoaXMucHJvcHMpXG4gIH1cblxuICBjb21wb25lbnRXaWxsUmVjZWl2ZVByb3BzKG5leHRQcm9wcykge1xuICAgIGlmIChuZXh0UHJvcHMubG9hZCAhPT0gdGhpcy5wcm9wcy5sb2FkKSB7XG4gICAgICB0aGlzLmxvYWQobmV4dFByb3BzKVxuICAgIH1cbiAgfVxuXG4gIGxvYWQocHJvcHMpIHtcbiAgICB0aGlzLnNldFN0YXRlKHtcbiAgICAgIG1vZDogbnVsbFxuICAgIH0pXG4gICAgcHJvcHNcbiAgICAgIC5sb2FkKClcbiAgICAgIC50aGVuKChtb2QpID0+IHtcbiAgICAgICAgdGhpcy5zZXRTdGF0ZSh7XG4gICAgICAgICAgLy8gaGFuZGxlIGJvdGggZXMgaW1wb3J0cyBhbmQgY2pzXG4gICAgICAgICAgbW9kOiBtb2QuZGVmYXVsdCA/IG1vZC5kZWZhdWx0IDogbW9kXG4gICAgICAgIH0pXG4gICAgICB9KVxuICAgIC8vIHByb3BzLmxvYWQoKG1vZCkgPT4ge1xuICAgIC8vICAgdGhpcy5zZXRTdGF0ZSh7XG4gICAgLy8gICAgIC8vIGhhbmRsZSBib3RoIGVzIGltcG9ydHMgYW5kIGNqc1xuICAgIC8vICAgICBtb2Q6IG1vZC5kZWZhdWx0ID8gbW9kLmRlZmF1bHQgOiBtb2RcbiAgICAvLyAgIH0pXG4gICAgLy8gfSlcbiAgfVxuXG4gIHJlbmRlcigpIHtcbiAgICByZXR1cm4gdGhpcy5zdGF0ZS5tb2QgPyB0aGlzLnByb3BzLmNoaWxkcmVuKHRoaXMuc3RhdGUubW9kKSA6IG51bGxcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBCdW5kbGVcblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi9zcmMvY29tcG9uZW50cy9CdW5kbGUuanMiLCJ2YXIgZGVmYXVsdFBheWxvYWRDcmVhdG9yID0gZnVuY3Rpb24gKHBheWxvYWQpIHtcblx0cmV0dXJuIHBheWxvYWQ7XG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uKHR5cGUsIHBheWxvYWRDcmVhdG9yKXtcblxuXHR2YXIgZmluaWFsUGF5bG9hZENyZWF0b3IgPSB0eXBlb2YgcGF5bG9hZENyZWF0b3IgPT09ICdmdW5jdGlvbidcblx0XHQ/IHBheWxvYWRDcmVhdG9yXG5cdFx0OiBkZWZhdWx0UGF5bG9hZENyZWF0b3I7XG5cblx0cmV0dXJuIGZ1bmN0aW9uICgpIHtcblx0XHR2YXIgcGF5bG9hZCA9IGZpbmlhbFBheWxvYWRDcmVhdG9yLmFwcGx5KG51bGwsIGFyZ3VtZW50cyk7XG5cblx0XHRpZiAodHlwZW9mIHBheWxvYWQgPT09ICdmdW5jdGlvbicpIHtcblx0XHRcdHJldHVybiBwYXlsb2FkO1xuXHRcdH0gZWxzZSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHR0eXBlOiB0eXBlLFxuXHRcdFx0XHRwYXlsb2FkOiBwYXlsb2FkXG5cdFx0XHR9O1xuXHRcdH1cblx0fTtcbn07XG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vc3JjL21vZHVsZXMvcmVkdXgtdXRpbC9jcmVhdGVBY3Rpb24uanMiLCJ2YXIgY3JlYXRlQWN0aW9uID0gcmVxdWlyZSgnLi9jcmVhdGVBY3Rpb24nKTtcbnZhciBjcmVhdGVBY3Rpb25zID0gcmVxdWlyZSgnLi9jcmVhdGVBY3Rpb25zJyk7XG52YXIgY3JlYXRlUmVkdWNlcnMgPSByZXF1aXJlKCcuL2NyZWF0ZVJlZHVjZXJzJyk7XG52YXIgY3JlYXRlUmVkdWNlciA9IHJlcXVpcmUoJy4vY3JlYXRlUmVkdWNlcicpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IHtcblx0Y3JlYXRlQWN0aW9uLFxuXHRjcmVhdGVBY3Rpb25zLFxuXHRjcmVhdGVSZWR1Y2Vycyxcblx0Y3JlYXRlUmVkdWNlclxufTtcblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi9zcmMvbW9kdWxlcy9yZWR1eC11dGlsL2luZGV4LmpzIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgcmVuZGVyIH0gZnJvbSAncmVhY3QtZG9tJ1xuXG5pbXBvcnQgeyBjcmVhdGVTdG9yZSwgYXBwbHlNaWRkbGV3YXJlLCBjb21iaW5lUmVkdWNlcnMgfSBmcm9tICdyZWR1eCdcbmltcG9ydCB0aHVuayBmcm9tICdyZWR1eC10aHVuaydcbmltcG9ydCB7IFByb3ZpZGVyLCBjb25uZWN0IH0gZnJvbSAncmVhY3QtcmVkdXgnXG5pbXBvcnQgcmVkdWNlcnMgZnJvbSAnLi4vcmVkdWNlcnMnXG5cbmltcG9ydCBjcmVhdGVIaXN0b3J5IGZyb20gJ2hpc3RvcnkvY3JlYXRlQnJvd3Nlckhpc3RvcnknXG5pbXBvcnQgeyBSb3V0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlcidcblxuaW1wb3J0IHsgQ29ubmVjdGVkUm91dGVyLCByb3V0ZXJSZWR1Y2VyLCByb3V0ZXJNaWRkbGV3YXJlLCBwdXNoIH0gZnJvbSAncmVhY3Qtcm91dGVyLXJlZHV4J1xuXG5jb25zdCBoaXN0b3J5ID0gY3JlYXRlSGlzdG9yeSgpXG5jb25zdCBtaWRkbGV3YXJlID0gcm91dGVyTWlkZGxld2FyZShoaXN0b3J5KVxuXG5oaXN0b3J5Lmxpc3RlbigobG9jYXRpb24sIGFjdGlvbikgPT4ge1xuICAvLyBsb2NhdGlvbiBpcyBhbiBvYmplY3QgbGlrZSB3aW5kb3cubG9jYXRpb25cbiAgY29uc29sZS5sb2coYWN0aW9uLCBsb2NhdGlvbi5wYXRobmFtZSwgbG9jYXRpb24uc3RhdGUpXG59KVxuXG5jb25zdCBzdG9yZSA9IGNyZWF0ZVN0b3JlKFxuICBjb21iaW5lUmVkdWNlcnMoe1xuICAgIC4uLnJlZHVjZXJzLFxuICAgIHJvdXRlcjogcm91dGVyUmVkdWNlclxuICB9KSxcbiAgYXBwbHlNaWRkbGV3YXJlKHRodW5rLCBtaWRkbGV3YXJlKVxuKVxuXG5jb25zdCBtYXBTdGF0ZVRvUHJvcHMgPSBmdW5jdGlvbihzdGF0ZSl7XG5cdHJldHVybiBzdGF0ZVxufVxuXG5pbXBvcnQgQXBwIGZyb20gJy4uL2NvbXBvbmVudHMvQXBwJ1xuXG4vLyDmoLflvI/mlofku7ZcbmltcG9ydCAnd2V1aSc7XG5pbXBvcnQgJ3JlYWN0LXdldWkvYnVpbGQvcGFja2FnZXMvcmVhY3Qtd2V1aS5jc3MnO1xuXG5yZW5kZXIoXG4gIDxQcm92aWRlciBzdG9yZT17c3RvcmV9PlxuICAgIHsgLyogQ29ubmVjdGVkUm91dGVyIHdpbGwgdXNlIHRoZSBzdG9yZSBmcm9tIFByb3ZpZGVyIGF1dG9tYXRpY2FsbHkgKi8gfVxuICAgIDxDb25uZWN0ZWRSb3V0ZXIgaGlzdG9yeT17aGlzdG9yeX0+XG5cdFx0XHQ8QXBwIGhpc3Rvcnk9e2hpc3Rvcnl9IC8+XG4gICAgPC9Db25uZWN0ZWRSb3V0ZXI+XG4gIDwvUHJvdmlkZXI+LFxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnY29udGFpbmVyJylcbilcblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi9zcmMvbGliL2FwcC5qcyIsImltcG9ydCB7IGNyZWF0ZVJlZHVjZXJzIH0gZnJvbSAncmVkdXgtdXRpbCdcblxudmFyIGxvZ2luQXBwID0gY3JlYXRlUmVkdWNlcnMoe1xuXHRnZXRJbml0aWFsU3RhdGU6IGZ1bmN0aW9uKCl7XG5cdFx0cmV0dXJuIHtcblx0XHRcdGxvZ2luU3RhdHVzOiAnJyxcblx0XHRcdHJlZ1N0YXR1czogJydcblx0XHR9O1xuXHR9LFxuXHRMT0dJTjogZnVuY3Rpb24oc3RhdGUsIGFjdGlvbil7XG5cdFx0c3RhdGUubG9naW5TdGF0dXMgPSAncGVuZGluZyc7XG5cdFx0cmV0dXJuIHN0YXRlO1xuXHR9XG59KTtcblxudmFyIHJlZ0FwcCA9IGNyZWF0ZVJlZHVjZXJzKHtcblx0Z2V0SW5pdGlhbFN0YXRlOiBmdW5jdGlvbigpe1xuXHRcdHJldHVybiB7XG5cdFx0XHRyZWdTdGF0dXM6ICcnLFxuXHRcdFx0cmVnU3RhdHVzOiAnJ1xuXHRcdH07XG5cdH0sXG5cdExPR0lOOiBmdW5jdGlvbihzdGF0ZSwgYWN0aW9uKXtcblx0XHRzdGF0ZS5yZWdTdGF0dXMgPSAncGVuZGluZyc7XG5cdFx0cmV0dXJuIHN0YXRlO1xuXHR9XG59KTtcblxuY29uc3QgcmVkdWNlciA9IHtcblx0bG9naW5BcHA6IGxvZ2luQXBwLFxuXHRyZWdBcHA6IHJlZ0FwcCxcbn1cblxuZXhwb3J0IGRlZmF1bHQgcmVkdWNlclxuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAuL3NyYy9yZWR1Y2Vycy9pbmRleC5qcyIsInZhciBjcmVhdGVBY3Rpb24gPSByZXF1aXJlKCcuL2NyZWF0ZUFjdGlvbicpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uKG9wdGlvbnMpe1xuXHR2YXIgYWN0aW9uTWFwID0ge307XG5cdGZvcih2YXIgdHlwZSBpbiBvcHRpb25zKXtcblx0XHRhY3Rpb25NYXBbdHlwZV0gPSBjcmVhdGVBY3Rpb24odHlwZSwgb3B0aW9uc1t0eXBlXSk7XG5cdH1cblx0cmV0dXJuIGFjdGlvbk1hcDtcbn07XG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vc3JjL21vZHVsZXMvcmVkdXgtdXRpbC9jcmVhdGVBY3Rpb25zLmpzIiwidmFyIF8gPSByZXF1aXJlKCdsb2Rhc2gnKTtcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAocmVkdWNlck1hcCkge1xuXG5cdHZhciBpbml0aWFsU3RhdGU7XG5cblx0aWYocmVkdWNlck1hcC5nZXRJbml0aWFsU3RhdGUpe1xuXHRcdGluaXRpYWxTdGF0ZSA9IHJlZHVjZXJNYXAuZ2V0SW5pdGlhbFN0YXRlKCk7XG5cdH1cblxuXHRyZXR1cm4gZnVuY3Rpb24gKHN0YXRlID0gaW5pdGlhbFN0YXRlLCBhY3Rpb24pIHtcblxuXHRcdHN0YXRlID0gXy5jbG9uZShzdGF0ZSk7XG5cblx0XHR2YXIgdHlwZSA9IGFjdGlvbi50eXBlO1xuXHRcdHZhciByZWR1Y2VyID0gcmVkdWNlck1hcFt0eXBlXTtcblxuXHRcdGlmKHR5cGVvZiByZWR1Y2VyID09PSAnZnVuY3Rpb24nKXtcblx0XHRcdHJldHVybiByZWR1Y2VyKHN0YXRlLCBhY3Rpb24pO1xuXHRcdH1lbHNle1xuXHRcdFx0cmV0dXJuIHN0YXRlO1xuXHRcdH1cblx0fTtcbn07XG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vc3JjL21vZHVsZXMvcmVkdXgtdXRpbC9jcmVhdGVSZWR1Y2Vycy5qcyIsIm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24odHlwZSwgcmVkdWNlciwgaW5pdGlhbFN0YXRlKXtcblx0cmV0dXJuIGZ1bmN0aW9uIChzdGF0ZSwgYWN0aW9uKSB7XG5cdFx0aWYoYWN0aW9uLnR5cGUgIT09IHR5cGUpIHJldHVybiBzdGF0ZTtcblxuXHRcdHJldHVybiByZWR1Y2VyKHR5cGUsIGFjdGlvbik7XG5cdH07XG59O1xuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAuL3NyYy9tb2R1bGVzL3JlZHV4LXV0aWwvY3JlYXRlUmVkdWNlci5qcyJdLCJzb3VyY2VSb290IjoiIn0=